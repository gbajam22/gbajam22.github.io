#ifndef MISSION_SOUND_0_H
#define MISSION_SOUND_0_H

#define MISSION_SOUND_0_CHANNEL 0
#define MISSION_SOUND_0_SIZE 7741440

extern const signed char mission_sound_0[7741440];

#endif
