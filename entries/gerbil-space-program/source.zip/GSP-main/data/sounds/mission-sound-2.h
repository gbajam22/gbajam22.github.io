#ifndef MISSION_SOUND_2_H
#define MISSION_SOUND_2_H

#define MISSION_SOUND_2_CHANNEL 0
#define MISSION_SOUND_2_SIZE 5529600

extern const signed char mission_sound_2[5529600];

#endif
