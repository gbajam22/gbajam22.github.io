#ifndef MISSION_SOUND_1_H
#define MISSION_SOUND_1_H

#define MISSION_SOUND_1_CHANNEL 0
#define MISSION_SOUND_1_SIZE 5713920

extern const signed char mission_sound_1[5713920];

#endif
