#ifndef TITLE_SOUND_H
#define TITLE_SOUND_H

#define TITLE_SOUND_CHANNEL 0
#define TITLE_SOUND_SIZE 5116800

extern const signed char title_sound[5116800];

#endif
