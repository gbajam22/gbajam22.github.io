#ifndef ALTITUDE_META_H
#define ALTITUDE_META_H

#define ALTITUDE_META_SIZE 256

extern const unsigned short altitude_meta[256];

#endif
