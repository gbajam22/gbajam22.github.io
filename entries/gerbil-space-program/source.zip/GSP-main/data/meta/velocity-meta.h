#ifndef VELOCITY_META_H
#define VELOCITY_META_H

#define VELOCITY_META_SIZE 256

extern const unsigned short velocity_meta[256];

#endif
