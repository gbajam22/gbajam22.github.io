#ifndef WALL_H
#define WALL_H

#include <seven/base/types.h>

extern const u8 wall_tiles[16384];

#endif
