
//{{BLOCK(m_engine_2)

//======================================================================
//
//	m_engine_2, 8x64@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 512 = 1024
//
//	Time-stamp: 2022-10-26, 22:35:27
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.16
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_M_ENGINE_2_H
#define GRIT_M_ENGINE_2_H

#define m_engine_2BitmapLen 512
extern const unsigned int m_engine_2Bitmap[128];

#define m_engine_2PalLen 512
extern const unsigned short m_engine_2Pal[256];

#endif // GRIT_M_ENGINE_2_H

//}}BLOCK(m_engine_2)
