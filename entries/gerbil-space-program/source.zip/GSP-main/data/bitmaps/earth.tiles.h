#ifndef EARTH_H
#define EARTH_H

#include <seven/base/types.h>

extern const u8 earth_tiles[1048576];

extern const u16 earth_palette[256];

#endif
