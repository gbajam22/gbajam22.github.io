#ifndef RENDERER_SHPERE_H
#define RENDERER_SHPERE_H

#include <seven/base/types.h>

void SphereRender(const u8 *, u8 *, u32, u32, u32, u32);

void EarthPause();

void EarthResume();

#endif
