#include <seven/base/types.h>
#include <seven/video/object.h>

#include "types.h"

Object object_buffer[128];
vu8 spaceship_buffer[0x4000] ALIGN(128);
