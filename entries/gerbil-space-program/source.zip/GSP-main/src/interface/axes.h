#ifndef INTERFACE_AXES_H
#define INTERFACE_AXES_H

#include "../types.h"

void AxesInit(void);

void AxesUpdate(s32 roll, s32 pitch, s32 yaw);

#endif
