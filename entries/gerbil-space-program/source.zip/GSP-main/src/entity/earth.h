#ifndef ENTITY_EARTH_H
#define ENTITY_EARTH_H

#include "../types.h"

void EarthInit(void);

void EarthDraw(SphereData *earth, u32);

#endif
