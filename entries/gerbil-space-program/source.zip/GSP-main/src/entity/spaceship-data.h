#include "../types.h"
#include "parts-data.h"

extern const PartData *center_column_parts[];
extern ColumnData center_column;
extern ColumnData side_column_1;
extern ColumnData side_column_2;
extern ColumnData side_column_3;
extern ColumnData *ship_columns[];