#include <seven/hw/input.h>

#include "input.h"
