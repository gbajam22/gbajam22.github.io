#ifndef CORE_INPUT_H
#define CORE_INPUT_H

#include <seven/hw/input.h>

// TODO

#endif
