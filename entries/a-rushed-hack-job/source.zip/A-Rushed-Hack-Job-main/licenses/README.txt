Mountain at Dusk Background:
ansimuz
https://opengameart.org/content/mountain-at-dusk-background
https://creativecommons.org/publicdomain/zero/1.0/

10 Impact/Shield Blocks:
StarNinjas
https://opengameart.org/content/10-impactshield-blocks
https://creativecommons.org/publicdomain/zero/1.0/

Swishes Sound Pack:
artisticdude
https://opengameart.org/content/swishes-sound-pack
https://creativecommons.org/publicdomain/zero/1.0/

Short alarm:
yd
https://opengameart.org/content/short-alarm
https://creativecommons.org/publicdomain/zero/1.0/

Music:
Nikku4211
https://modarchive.org/index.php?request=view_by_moduleid&query=183062
https://modarchive.org/index.php?request=view_by_moduleid&query=193012