# YALAXY-01

This is a rather ambitious project I'll be working on for the next few weeks and months, here's what I've got so far; it's going to be a "boss-rush" style game but so far it's just a square-circle here :P (very imposing), the code's all messy with if's too, gotta clean that up later! The player character has their arsenal viewable with different sprites and/or animations for each tool

# Controls:

Left & Right - Movement

Hold Down then Left or Right - Quick Teleport

A - Fire

B - Slash

L & R - Cycle Colours

# Special Thanks:

Butano - very very cool engine

Tonc - also very very cool

All the other technical stuff and people that made the good things - you're a real cool person
