#pragma once

#include <Astralbrew>

extern const obj_class_t $(GHOST);
extern const obj_class_t $(FIREFLY);