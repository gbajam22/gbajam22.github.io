#pragma once

unsigned int qrand();