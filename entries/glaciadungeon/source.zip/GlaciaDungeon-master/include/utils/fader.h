#pragma once

#include <gba.h>

extern u16* SH_BG_PALETTE;
extern u16* SH_SPRITE_PALETTE;

void shpal_set_black();
void shpal_fade();
