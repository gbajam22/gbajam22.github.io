#pragma once

struct MapSource
{	
	int tiles_width;
	int tiles_height;
	const unsigned char* source;
};