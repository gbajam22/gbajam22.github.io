#include "regs.hpp"

register_class(GHOST);
register_class(FIREFLY);