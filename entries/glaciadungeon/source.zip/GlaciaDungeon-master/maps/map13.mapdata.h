#include "map13.maps.h"

#define MAP_DATA_map13 cr_map(map13, 596, 104, 220, 122)
