#include "map2.maps.h"

#define MAP_DATA_map2 cr_map(map2, 746, 616, 1006, 1316)
