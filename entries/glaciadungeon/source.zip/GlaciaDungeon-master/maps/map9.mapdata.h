#include "map9.maps.h"

#define MAP_DATA_map9 cr_map(map9, 676, 416, 666, 332)
