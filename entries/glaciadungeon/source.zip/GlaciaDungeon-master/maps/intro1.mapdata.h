#include "intro1.maps.h"

#define MAP_DATA_intro1 cr_map(intro1, 182, 336, 448, 572)
