#include "map18.maps.h"

#define MAP_DATA_map18 cr_map(map18, 154, 512, 180, 388)
