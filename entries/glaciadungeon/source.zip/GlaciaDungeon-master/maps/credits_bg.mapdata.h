#include "credits_bg.maps.h"

#define MAP_DATA_credits_bg cr_map(credits_bg, -1, -1, -1, -1)
