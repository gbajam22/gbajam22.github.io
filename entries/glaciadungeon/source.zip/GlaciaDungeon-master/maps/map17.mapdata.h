#include "map17.maps.h"

#define MAP_DATA_map17 cr_map(map17, 194, 776, 168, 314)
