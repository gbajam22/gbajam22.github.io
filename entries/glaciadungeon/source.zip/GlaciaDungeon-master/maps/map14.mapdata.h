#include "map14.maps.h"

#define MAP_DATA_map14 cr_map(map14, 476, 544, 56, 536)
