#include "intro3.maps.h"

#define MAP_DATA_intro3 cr_map(intro3, 912, 900, 102, 84)
