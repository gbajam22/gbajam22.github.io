#include "map1.maps.h"

#define MAP_DATA_map1 cr_map(map1, 580, 206, 526, 1990)
