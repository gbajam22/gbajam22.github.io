#include "map19.maps.h"

#define MAP_DATA_map19 cr_map(map19, 186, 808, 214, 158)
