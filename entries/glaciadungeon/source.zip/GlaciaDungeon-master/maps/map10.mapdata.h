#include "map10.maps.h"

#define MAP_DATA_map10 cr_map(map10, 144, 832, 642, 76)
