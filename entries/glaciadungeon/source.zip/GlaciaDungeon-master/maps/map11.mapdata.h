#include "map11.maps.h"

#define MAP_DATA_map11 cr_map(map11, 750, 94, 288, 490)
