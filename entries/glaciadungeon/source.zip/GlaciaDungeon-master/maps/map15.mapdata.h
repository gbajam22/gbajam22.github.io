#include "map15.maps.h"

#define MAP_DATA_map15 cr_map(map15, 168, 430, 172, 118)
