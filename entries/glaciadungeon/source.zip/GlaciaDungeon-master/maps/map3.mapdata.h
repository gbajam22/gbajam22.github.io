#include "map3.maps.h"

#define MAP_DATA_map3 cr_map(map3, 954, 1268, 584, 100)
