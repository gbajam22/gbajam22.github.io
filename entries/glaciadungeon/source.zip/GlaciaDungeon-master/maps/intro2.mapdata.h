#include "intro2.maps.h"

#define MAP_DATA_intro2 cr_map(intro2, 436, 108, 54, 436)
