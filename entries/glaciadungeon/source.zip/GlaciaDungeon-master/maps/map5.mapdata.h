#include "map5.maps.h"

#define MAP_DATA_map5 cr_map(map5, 996, 492, 608, 70)
