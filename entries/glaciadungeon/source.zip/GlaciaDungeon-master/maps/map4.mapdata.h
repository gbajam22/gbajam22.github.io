#include "map4.maps.h"

#define MAP_DATA_map4 cr_map(map4, 359*4, 214*4, 762*4, 268*4)
