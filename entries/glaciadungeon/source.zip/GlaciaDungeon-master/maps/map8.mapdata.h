#include "map8.maps.h"

#define MAP_DATA_map8 cr_map(map8, 130, 458, 790, 344)
