#include "map20.maps.h"

#define MAP_DATA_map20 cr_map(map20, 664, 432, 664, 88)
