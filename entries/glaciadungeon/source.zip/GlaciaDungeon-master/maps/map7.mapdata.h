#include "map7.maps.h"

#define MAP_DATA_map7 cr_map(map7, 650, 64, 714, 568)
