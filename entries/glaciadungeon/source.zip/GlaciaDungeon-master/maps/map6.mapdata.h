#include "map6.maps.h"

#define MAP_DATA_map6 cr_map(map6, 1840, 368, 1890, 348)
