#include "map16.maps.h"

#define MAP_DATA_map16 cr_map(map16, 490, 76, 134, 700)
