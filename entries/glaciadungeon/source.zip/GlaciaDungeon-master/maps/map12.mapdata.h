#include "map12.maps.h"

#define MAP_DATA_map12 cr_map(map12, 750, 94, 90, 624)
