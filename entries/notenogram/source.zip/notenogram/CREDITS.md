* Programming, inbuilt puzzles, art, sounds, pixel demake of GBA Jam 2022 logo -- [kva64] (*code distributed under zlib license, art and sounds - CC BY 4.0*)
* Engine -- Butano by [GValiente](https://github.com/gvaliente) (*zlib license with multiple attributes* (see *licenses* folder))
* Music -- *Which Brand Of Mustard Shall I Buy* by [congusbongus](https://modarchive.org/index.php?request=view_profile&query=85757) (*CC0 license*)
* Original GBA Jam 2022 logo designs -- [foopod/Jono Shields](https://foopod.itch.io), [exelotl](https://exelo.tl) (logo asset attributions can be found [here](https://gbajam22.github.io))
