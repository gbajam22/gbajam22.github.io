#include "picross_solutions.h"

namespace puzzle
{

}
