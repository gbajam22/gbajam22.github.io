#include "scenes/title.hpp"

#include "levels/level10.hpp"
#include "scenes/intro.hpp"

astralbrew_launch(Intro);
//astralbrew_launch(Title);
//astralbrew_launch(Level10);

