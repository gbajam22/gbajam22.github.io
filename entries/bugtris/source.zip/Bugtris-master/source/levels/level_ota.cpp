#include "levels/level_ota.hpp"

void LevelOTA::set_level(Level* level) 
{
	this->level = level;
}