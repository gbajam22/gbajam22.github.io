
//{{BLOCK(axe)

//======================================================================
//
//	axe, 32x32@4, 
//	+ palette 16 entries, not compressed
//	+ 16 tiles Metatiled by 4x4 not compressed
//	Total size: 32 + 512 = 544
//
//	Time-stamp: 2022-10-17, 17:27:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_AXE_H
#define GRIT_AXE_H

#define axeTilesLen 512
extern const unsigned int axeTiles[128];

#define axePalLen 32
extern const unsigned int axePal[8];

#endif // GRIT_AXE_H

//}}BLOCK(axe)
