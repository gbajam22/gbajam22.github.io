
//{{BLOCK(gameOverScreen)

//======================================================================
//
//	gameOverScreen, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2022-10-23, 01:04:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEOVERSCREEN_H
#define GRIT_GAMEOVERSCREEN_H

#define gameOverScreenBitmapLen 76800
extern const unsigned int gameOverScreenBitmap[19200];

#endif // GRIT_GAMEOVERSCREEN_H

//}}BLOCK(gameOverScreen)
