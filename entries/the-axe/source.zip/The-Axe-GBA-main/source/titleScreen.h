
//{{BLOCK(titleScreen)

//======================================================================
//
//	titleScreen, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2022-10-09, 16:04:19
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TITLESCREEN_H
#define GRIT_TITLESCREEN_H

#define titleScreenBitmapLen 76800
extern const unsigned int titleScreenBitmap[19200];

#endif // GRIT_TITLESCREEN_H

//}}BLOCK(titleScreen)
