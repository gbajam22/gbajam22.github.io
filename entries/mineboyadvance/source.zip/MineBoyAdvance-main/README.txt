This is my submission for GBA Jam 2022.

It is a 2D voxel game inspired by minecraft with "infinite" "random" terrain.

Control:

Arrow Keys -			Move/Break/Place
Hold A -			go into Place Mode
Hold B -			go into Break Mode
Hold Right Trigger -		Aim Down (to Place and Break blocks at Ground Level with Left or Right Keys)
Hold Left Trigger -		Aim Up (to Place and Break blocks at Eye Level with Left or Right Keys)
Start -				Shift selected Inventory slot to the right
Select -			Shift selected Inventory slot to the left
Hold A + Start + Select for 3s-	a New Random World will be generated on restart (the first world generated is always the same)

This game was built from 3DSage's GBA template.