# Rock Paper Shotgun tactics
A WiP tactics game for the GBA

The game meant to be for the GBA Jam 2022 but its still a WiP. I couldn't complete it because of school and irl stuff.

Right now, it's just a demo of working pathfinder. There's just one AI unit that moves towards the player unit. The unit selection menu doesn't work. It just shows the possible moves that the player can make.

The game once completed will have a weapon triangle system like Fire Emblem.

## Screenshots

<img src="https://raw.githubusercontent.com/pyroceper/rock_paper_shotgun_tactics/main/img/pathfinding-0.png" alt="pathfinding_0"/>
<img src="https://raw.githubusercontent.com/pyroceper/rock_paper_shotgun_tactics/main/img/pathfinding-1.png" alt="pathfinding_1"/>
<img src="https://raw.githubusercontent.com/pyroceper/rock_paper_shotgun_tactics/main/img/pathfinding-2.png" alt="pathfinding_2"/>

## Credits
### Game Engine
[Butano](https://github.com/GValiente/butano)
### Art Assets
[mattwalkden](https://mattwalkden.itch.io/free-robot-warfare-pack)
