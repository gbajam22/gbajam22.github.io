#ifndef DAMAGE_FORMULA_H
#define DAMAGE_FORMULA_H

namespace Runa::Game
{

int Damage_calculator(int str, int weapon, int def, int armor);

} // namespace Runa::Game

#endif // DAMAGE_FORMULA_H
