<p align="center"><img width="500" src=".github/HEXES - Logo.png" alt="HEXES Segments Logo"></p>

HEXES, The fast-paced puzzle shoot'em up!

Check out [our itch.io page](https://kaleidosium.itch.io/hexes) for more information about the game!

# Credits

Programming by: [Kaleidosium](https://github.com/Kaleidosium)

Music and SFX by: [kathound](https://kathrynhathaway.bandcamp.com/)

## Special Thanks

- [exelotl](https://natu.exelo.tl/), along with PyroPyro for Natu and XNIQ's code
- [Jeti](https://fontenddev.com/) for the fonts used or derived
- [Jonathan So](https://jonathan-so.itch.io/creatorpack) for *The Game Creator's Pack*, used temporarily during development
- [Mark Brown](https://www.youtube.com/c/MarkBrownGMT/) for the *Developing* series
- Justburner for some minor math help

## License

[MIT](LICENSE)
