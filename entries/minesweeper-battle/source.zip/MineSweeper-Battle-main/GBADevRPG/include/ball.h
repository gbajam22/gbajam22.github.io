
//{{BLOCK(ball)

//======================================================================
//
//	ball, 32x32@4, 
//	+ palette 16 entries, not compressed
//	+ 16 tiles not compressed
//	Total size: 32 + 512 = 544
//
//	Time-stamp: 2022-09-20, 09:51:49
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.16
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BALL_H
#define GRIT_BALL_H

#define ballTilesLen 512
extern const unsigned int ballTiles[128];

#define ballPalLen 32
extern const unsigned short ballPal[16];

#endif // GRIT_BALL_H

//}}BLOCK(ball)
