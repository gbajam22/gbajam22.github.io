
//{{BLOCK(playerSprite)

//======================================================================
//
//	playerSprite, 16x224@4, 
//	+ palette 16 entries, not compressed
//	+ 56 tiles not compressed
//	Total size: 32 + 1792 = 1824
//
//	Time-stamp: 2022-09-04, 20:46:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.16
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PLAYERSPRITE_H
#define GRIT_PLAYERSPRITE_H

#define playerSpriteTilesLen 1792
extern const unsigned int playerSpriteTiles[448];

#define playerSpritePalLen 32
extern const unsigned short playerSpritePal[16];

#endif // GRIT_PLAYERSPRITE_H

//}}BLOCK(playerSprite)
