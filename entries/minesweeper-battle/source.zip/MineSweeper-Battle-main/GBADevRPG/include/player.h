
//{{BLOCK(player)

//======================================================================
//
//	player, 32x96@4, 
//	+ palette 16 entries, not compressed
//	+ 48 tiles not compressed
//	Total size: 32 + 1536 = 1568
//
//	Time-stamp: 2022-09-19, 15:34:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.16
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PLAYER_H
#define GRIT_PLAYER_H

#define playerTilesLen 1536
extern const unsigned int playerTiles[384];

#define playerPalLen 32
extern const unsigned short playerPal[16];

#endif // GRIT_PLAYER_H

//}}BLOCK(player)
